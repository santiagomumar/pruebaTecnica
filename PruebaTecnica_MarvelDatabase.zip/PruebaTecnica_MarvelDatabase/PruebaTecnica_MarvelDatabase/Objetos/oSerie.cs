﻿namespace PruebaTecnica_MarvelDatabase.Objetos
{
    internal class oSerie
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public int Total_Characters { get; set; }
    }
}
